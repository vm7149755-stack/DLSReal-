package com.dlsreal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.dlsreal.STOP"
        private const val CHANNEL = "dlsreal"
        private const val NOTIF_ID = 7
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences

    private var lighting: LightingView? = null
    private var tab: LinearLayout? = null
    private var tabLp: WindowManager.LayoutParams? = null
    private var toggle: TextView? = null
    private var panel: LinearLayout? = null
    private val chips = mutableListOf<TextView>()
    private var on = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (tab == null) buildUi()
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "DLS Real", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("DLS Real ativo")
            .setContentText("Use a aba preta para ligar/desligar")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Desativar", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildUi() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("dlsreal", MODE_PRIVATE)

        // ---- camada de iluminação (tela cheia, toques passam para o jogo) ----
        val lv = LightingView(this).apply {
            preset = prefs.getInt("preset", 0)
            shadow = prefs.getInt("shadow", 60)
            light = prefs.getInt("light", 60)
            visibility = View.GONE
        }
        val lightLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lightLp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(lv, lightLp)
        lighting = lv

        // ---- aba preta pequena ----
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE000000"))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tg = TextView(this).apply {
            textSize = 13f
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        toggle = tg
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 16f; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 14f; setTextColor(Color.parseColor("#FF6B6B"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { stopSelf() }
        }
        row.addView(tg); row.addView(gear); row.addView(close)
        root.addView(row)

        val p = buildPanel()
        panel = p
        root.addView(p)
        gear.setOnClickListener {
            p.visibility = if (p.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            tabLp?.let { wm.updateViewLayout(root, it) }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("tabX", dp(8))
            y = prefs.getInt("tabY", dp(120))
        }
        tabLp = lp
        tab = root

        // arrastar pela palavra ON/OFF; toque simples liga/desliga
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        tg.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx; lp.y = startY + dy
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("tabX", lp.x).putInt("tabY", lp.y).apply()
                    else setOn(!on)
                    true
                }
                else -> false
            }
        }

        wm.addView(root, lp)
        setOn(false)
        refreshChips()
    }

    private fun setOn(v: Boolean) {
        on = v
        toggle?.apply {
            text = if (v) "● ON" else "● OFF"
            setTextColor(Color.parseColor(if (v) "#4CAF50" else "#9E9E9E"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        lighting?.visibility = if (v) View.VISIBLE else View.GONE
        lighting?.setRunning(v)
    }

    private fun buildPanel(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            minimumWidth = dp(230)
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        LightingView.NAMES.forEachIndexed { i, name ->
            val chip = TextView(this).apply {
                text = name; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    lighting?.preset = i
                    prefs.edit().putInt("preset", i).apply()
                    refreshChips()
                }
            }
            chips.add(chip)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            (if (i < 3) row1 else row2).addView(chip, lp)
        }
        box.addView(row1); box.addView(row2)
        box.addView(seekRow("Sombra", prefs.getInt("shadow", 60)) { v, final ->
            lighting?.shadow = v
            if (final) prefs.edit().putInt("shadow", v).apply()
        })
        box.addView(seekRow("Iluminação", prefs.getInt("light", 60)) { v, final ->
            lighting?.light = v
            if (final) prefs.edit().putInt("light", v).apply()
        })
        return box
    }

    private fun seekRow(label: String, init: Int, onChange: (Int, Boolean) -> Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        col.addView(TextView(this).apply {
            text = label; textSize = 11f; setTextColor(Color.parseColor("#BBBBBB"))
        })
        col.addView(SeekBar(this).apply {
            max = 100; progress = init
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) = onChange(p, false)
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) = onChange(s.progress, true)
            })
        })
        return col
    }

    private fun refreshChips() {
        val sel = lighting?.preset ?: 0
        chips.forEachIndexed { i, c ->
            c.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor(if (i == sel) "#2E7D32" else "#2B2B2F"))
            }
        }
    }

    override fun onDestroy() {
        runCatching { lighting?.let { wm.removeView(it) } }
        runCatching { tab?.let { wm.removeView(it) } }
        lighting = null; tab = null
        super.onDestroy()
    }
}
