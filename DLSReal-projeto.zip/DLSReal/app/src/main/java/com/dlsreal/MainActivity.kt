package com.dlsreal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var waitingOverlayPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#0E0E10"))
        }
        root.addView(TextView(this).apply {
            text = "DLS Real"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Toque em Ativar, abra o jogo e use a aba preta pequena (OFF/ON) para ligar a iluminação e as sombras."
            textSize = 14f
            setTextColor(Color.parseColor("#B0B0B8"))
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        })
        root.addView(Button(this).apply {
            text = "Ativar"
            setOnClickListener { activate() }
        })
        root.addView(Button(this).apply {
            text = "Desativar"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        setContentView(root)
    }

    private fun activate() {
        if (!Settings.canDrawOverlays(this)) {
            waitingOverlayPermission = true
            Toast.makeText(this, "Permita \"Exibir sobre outros apps\" e volte.", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        launchOverlay()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        launchOverlay() // funciona mesmo sem a notificação visível
    }

    override fun onResume() {
        super.onResume()
        if (waitingOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingOverlayPermission = false
            activate()
        }
    }

    private fun launchOverlay() {
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Aba ativada. Abra o jogo e toque em OFF para ligar.", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)
    }
}
