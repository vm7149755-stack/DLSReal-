package com.dlsreal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/** Camada de iluminação dinâmica + sombras desenhada por cima do jogo (não captura a tela). */
class LightingView(context: Context) : View(context) {

    class Look(
        val tint: Int, val tintA: Float,
        val light: Int, val lightA: Float,
        val fill: Int, val fillA: Float,
        val dark: Float
    )

    companion object {
        val NAMES = listOf("Dia", "Tarde", "Noite", "Cinema", "Ciclo")
        val LOOKS = listOf(
            Look(Color.parseColor("#FFF1D6"), 0.06f, Color.parseColor("#FFF4D6"), 0.30f, Color.parseColor("#9CC4FF"), 0.10f, 0.9f),
            Look(Color.parseColor("#FF8A3D"), 0.12f, Color.parseColor("#FF9E4A"), 0.38f, Color.parseColor("#7A5CFF"), 0.10f, 1.0f),
            Look(Color.parseColor("#1A2A5C"), 0.22f, Color.parseColor("#9FB8FF"), 0.22f, Color.parseColor("#4C6BFF"), 0.10f, 1.25f),
            Look(Color.parseColor("#0F3A44"), 0.10f, Color.parseColor("#FFD9A0"), 0.28f, Color.parseColor("#2E6F8F"), 0.12f, 1.15f)
        )
        private const val CYCLE_STEP_SECONDS = 30f
        private val CYCLE_ORDER = intArrayOf(0, 1, 2, 1) // dia -> tarde -> noite -> tarde
    }

    var preset = 0
        set(v) { field = v; invalidate() }
    var shadow = 60 // 0..100 (60 = valor padrão do preset)
        set(v) { field = v; invalidate() }
    var light = 60
        set(v) { field = v; invalidate() }

    private var running = false
    private val t0 = SystemClock.uptimeMillis()

    private val pFill = Paint()
    private val pShade = Paint()
    private val pVig = Paint()
    private val pLight = Paint()
    private val pBeam = Paint()

    private var topShader: Shader? = null
    private var bottomShader: Shader? = null
    private var lightR = 1f
    private var beamHalfW = 1f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        val fw = w.toFloat(); val fh = h.toFloat()
        lightR = max(fw, fh) * 0.8f
        beamHalfW = fw * 0.10f

        topShader = LinearGradient(0f, 0f, 0f, fh * 0.4f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        bottomShader = LinearGradient(0f, fh, 0f, fh * 0.6f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)

        pLight.shader = RadialGradient(
            0f, 0f, lightR,
            intArrayOf(Color.WHITE, Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        pVig.shader = RadialGradient(
            fw / 2, fh / 2, hypot(fw, fh) / 2,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.BLACK),
            floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
        )
        pBeam.shader = LinearGradient(
            -beamHalfW, 0f, beamHalfW, 0f,
            intArrayOf(Color.argb(0, 255, 255, 255), Color.WHITE, Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    fun setRunning(r: Boolean) {
        running = r
        if (r) invalidate()
    }

    private fun a(x: Float) = (x.coerceIn(0f, 0.9f) * 255).toInt()

    private fun mix(c1: Int, c2: Int, f: Float): Int {
        fun ch(s: Int) = (((c1 shr s) and 255) * (1 - f) + ((c2 shr s) and 255) * f).toInt()
        return Color.rgb(ch(16), ch(8), ch(0))
    }

    private fun lerp(x: Float, y: Float, f: Float) = x + (y - x) * f

    private fun currentLook(t: Float): Look {
        if (preset < LOOKS.size) return LOOKS[preset]
        val p = t / CYCLE_STEP_SECONDS
        val i = p.toInt()
        val raw = p - i
        val f = raw * raw * (3 - 2 * raw)
        val l1 = LOOKS[CYCLE_ORDER[i % CYCLE_ORDER.size]]
        val l2 = LOOKS[CYCLE_ORDER[(i + 1) % CYCLE_ORDER.size]]
        return Look(
            mix(l1.tint, l2.tint, f), lerp(l1.tintA, l2.tintA, f),
            mix(l1.light, l2.light, f), lerp(l1.lightA, l2.lightA, f),
            mix(l1.fill, l2.fill, f), lerp(l1.fillA, l2.fillA, f),
            lerp(l1.dark, l2.dark, f)
        )
    }

    private fun drawLight(c: Canvas, x: Float, y: Float, color: Int, alpha: Float) {
        c.save()
        c.translate(x, y)
        pLight.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        pLight.alpha = a(alpha)
        c.drawCircle(0f, 0f, lightR, pLight)
        c.restore()
    }

    private fun drawBeam(c: Canvas, cx: Float, cy: Float, angle: Float, widthScale: Float, color: Int, alpha: Float) {
        c.save()
        c.translate(cx, cy)
        c.rotate(angle)
        c.scale(widthScale, 1f)
        pBeam.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        pBeam.alpha = a(alpha)
        c.drawRect(-beamHalfW, -height * 1.5f, beamHalfW, height * 1.5f, pBeam)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val lk = currentLook(t)
        val sf = shadow / 60f
        val lf = light / 60f

        // 1) cor ambiente (grading)
        pFill.color = lk.tint
        pFill.alpha = a(lk.tintA * (0.6f + 0.4f * sf))
        c.drawRect(0f, 0f, w, h, pFill)

        // 2) sombra de céu (topo) e de chão (base)
        pShade.shader = topShader
        pShade.alpha = a(0.34f * sf)
        c.drawRect(0f, 0f, w, h * 0.4f, pShade)
        pShade.shader = bottomShader
        pShade.alpha = a(0.40f * sf)
        c.drawRect(0f, h * 0.6f, w, h, pShade)

        // 3) vinheta / oclusão nos cantos
        pVig.alpha = a(0.60f * lk.dark * sf)
        c.drawRect(0f, 0f, w, h, pVig)

        // 4) luzes dinâmicas em movimento (sol principal + luz de preenchimento)
        val flick = 1f + 0.04f * sin(t * 3.1f) + 0.03f * sin(t * 7.3f)
        drawLight(
            c, w * (0.5f + 0.38f * sin(t * 0.21f)), h * (0.25f + 0.15f * cos(t * 0.17f)),
            lk.light, lk.lightA * lf * flick
        )
        drawLight(
            c, w * (0.5f + 0.40f * cos(t * 0.13f + 1f)), h * (0.75f + 0.12f * sin(t * 0.23f)),
            lk.fill, lk.fillA * lf
        )

        // 5) feixes de luz (god rays) varrendo a tela
        val beamA = 0.07f * lf * (lk.lightA / 0.3f)
        drawBeam(c, w * (0.5f + 0.35f * sin(t * 0.09f)), h * 0.5f, -24f, 1f, lk.light, beamA)
        drawBeam(c, w * (0.5f + 0.40f * sin(t * 0.06f + 2f)), h * 0.5f, -24f, 0.45f, lk.light, beamA * 0.8f)

        if (running) postInvalidateOnAnimation() // sincronizado com o vsync: 60 fps (ou a taxa da tela)
    }
}
